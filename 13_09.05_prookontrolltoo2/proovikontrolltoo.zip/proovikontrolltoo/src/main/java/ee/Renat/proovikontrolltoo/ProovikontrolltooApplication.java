package ee.Renat.proovikontrolltoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProovikontrolltooApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProovikontrolltooApplication.class, args);
	}

}
