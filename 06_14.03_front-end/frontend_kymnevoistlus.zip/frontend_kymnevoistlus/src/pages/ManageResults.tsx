

function ManageResults() {
  return (
    <div>ManageResults</div>
  )
}

export default ManageResults