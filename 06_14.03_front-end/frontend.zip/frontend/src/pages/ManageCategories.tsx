

function ManageCategories() {
  return (
    <div>ManageCategories</div>
  )
}

export default ManageCategories