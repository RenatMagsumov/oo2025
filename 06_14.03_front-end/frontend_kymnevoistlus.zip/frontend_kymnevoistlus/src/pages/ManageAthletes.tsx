import { useEffect, useRef, useState } from "react";
import { Athlete } from "../models/Athlete";
import { ToastContainer, toast } from 'react-toastify';

function ManageAthletes() {
 
const [athletes, setAthletes] = useState<Athlete[]>([]);
 
useEffect(() => {
  fetch("http://localhost:5074/athletes")
      .then(res=>res.json())
      .then(json=> setAthletes(json))
}, []);
 
const deleteAthlete = (id: number) => {
  fetch(`http://localhost:5074/athletes/${id}`, {
    method: "DELETE",
  }).then(res=>res.json())
    .then(json=> {
      if (json.message === undefined && json.timestamp === undefined 
                      && json.status === undefined) {
        setAthletes(json);
        toast.success("Athlete kustutatud!");
      } else {
        toast.error(json.message);
      }
    })
};

const nameRef = useRef<HTMLInputElement>(null);
const countryRef = useRef<HTMLInputElement>(null);
const ageRef = useRef<HTMLInputElement>(null);
const activeRef = useRef<HTMLInputElement>(null);



const addAthlete = () => {
  const newAthlete = {name: nameRef.current?.value, 
                    active: activeRef.current?.checked}

  fetch("http://localhost:5074/athletes", {
    method: "POST",
    body: JSON.stringify(newAthlete),
    headers: {
      "Content-Type": "application/json"
    }
  }).then(res=>res.json())
    .then(json=> {
      if (json.message === undefined && json.timestamp === undefined 
                      && json.status === undefined) {
        setAthletes(json);
        toast.success("Uus athlete lisatud!");
        if (nameRef.current && activeRef.current) {
          nameRef.current.value = "";
          activeRef.current.checked = false;
        }
      } else {
        toast.error(json.message);
      }
    })
}

return (
 
  <div>
    <h2>Manage Athletes</h2>
    <label>Name</label> <br />
    <input ref={nameRef} type="text" /> <br />
    <label>Country</label> <br />
    <input ref={countryRef} type="text" /> <br />
    <label>Age</label> <br />
    <input ref={ageRef} type="number" /> <br />
    <label>Active</label> <br />
    <input ref={activeRef} type="checkbox" /> <br />
    <button onClick={() => addAthlete()}>Add</button>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Active</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {athletes.map((athlete) => (
          <tr key={athlete.id}>
            <td>{athlete.id}</td>
            <td>{athlete.name}</td>
            <td>{athlete.country}</td>
            <td>{athlete.age}</td>
            <td>
              <button onClick={() => deleteAthlete(athlete.id)}>Delete</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
    <ToastContainer />
  </div>
);
}
 
export default ManageAthletes