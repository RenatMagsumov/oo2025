import { useEffect, useState } from "react";
import { Result } from "../models/Result";

function Results() 
{
    const[results, setResults] = useState<Result[]>([ ])
    useEffect(() => 
    {
        fetch("http://localhost:5074/results")
        .then(res => res.json())
        .then(json => console.log(json))
    }, []);
  return (
    <div>
      {results.map(result =>
        <div key={result.id}>
          <div>ID: {result.id}</div>
          <div>Event: {result.event}</div>
          <div>Score: {result.score}</div>
          
          <div>{result.athletes.map(athlete => 
            <div key = {athlete.id}> 
              <div>{athlete.name}</div>
              <div>{athlete.country}</div>
              <div>{athlete.age} years old</div>
            </div>)}
          </div>
        </div>
      )}
    </div>
  )
}

export default Results