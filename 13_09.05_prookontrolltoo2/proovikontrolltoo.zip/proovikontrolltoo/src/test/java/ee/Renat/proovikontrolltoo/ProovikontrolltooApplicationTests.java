package ee.Renat.proovikontrolltoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProovikontrolltooApplicationTests {

	@Test
	void contextLoads() {
	}

}
