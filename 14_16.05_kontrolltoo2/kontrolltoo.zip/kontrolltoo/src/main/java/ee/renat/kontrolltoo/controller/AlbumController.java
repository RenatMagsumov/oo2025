package ee.renat.kontrolltoo.controller;

import ee.renat.kontrolltoo.entity.Album;
import ee.renat.kontrolltoo.repository.AlbumRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/albums")
@CrossOrigin(origins = "*")
public class AlbumController {

    @Autowired
    private AlbumRepository albumRepository;

    @GetMapping
    public List<Album> getAllAlbums() {
        return (List<Album>) albumRepository.findAll();
    }

    @GetMapping("/paged")
    public Page<Album> getPagedAlbums(Pageable pageable) {
        return albumRepository.findAll(pageable);
    }

    @GetMapping("/{id}")
    public Optional<Album> getAlbumById(@PathVariable Long id) {
        return albumRepository.findById(id);
    }

    @PostMapping
    public Album createAlbum(@RequestBody Album album) {
        return albumRepository.save(album);
    }

    @PutMapping("/{id}")
    public Album updateAlbum(@PathVariable Long id, @RequestBody Album updatedAlbum) {
        return albumRepository.findById(id)
                .map(album -> {
                    album.setTitle(updatedAlbum.getTitle());
                    album.setUserId(updatedAlbum.getUserId());
                    return albumRepository.save(album);
                })
                .orElseGet(() -> {
                    updatedAlbum.setId(id);
                    return albumRepository.save(updatedAlbum);
                });
    }

    @DeleteMapping("/{id}")
    public void deleteAlbum(@PathVariable Long id) {
        albumRepository.deleteById(id);
    }
}
