
    export type Athlete = 
    {
        
        name: string,
        country: string,
        age: number
    }