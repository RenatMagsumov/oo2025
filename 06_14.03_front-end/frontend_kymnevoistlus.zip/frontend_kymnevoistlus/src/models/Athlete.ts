
    export type Athlete = 
    {
        id: number,
        name: string,
        country: string,
        age: number
    }