package ee.renat.kontrolltoo.repository;

import ee.renat.kontrolltoo.entity.Album;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlbumRepository extends JpaRepository<Album, Long> {
}


