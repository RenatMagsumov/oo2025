import { useEffect, useState } from "react";
import AlbumCard from "../components/AlbumCard";
import { Album } from "../models/album";
import "../App.css"; 
function AlbumListPage() {
  const [albums, setAlbums] = useState<Album[]>([]);
  const [page, setPage] = useState(0);
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const pageSize = 3;

  useEffect(() => {
    fetch("http://localhost:5074/albums")
      .then((res) => res.json())
      .then((data) => setAlbums(data));
  }, []);

  const sortedAlbums = [...albums].sort((a, b) => {
    const t1 = a.title.toLowerCase();
    const t2 = b.title.toLowerCase();
    return sortOrder === "asc" ? t1.localeCompare(t2) : t2.localeCompare(t1);
  });

  const totalPages = Math.ceil(sortedAlbums.length / pageSize);
  const paginatedAlbums = sortedAlbums.slice(page * pageSize, (page + 1) * pageSize);

  const handleSortToggle = () => {
    setSortOrder((prev) => (prev === "asc" ? "desc" : "asc"));
    setPage(0);
  };

  return (
    <div>
      <h2>Albumid</h2>

      <p>
        Leht <strong>{page + 1}</strong> / {totalPages} &nbsp;
        (kokku {albums.length} albumit)
      </p>

      <button onClick={handleSortToggle} style={{ marginBottom: "10px" }}>
        Sorteeri: {sortOrder === "asc" ? "A → Z" : "Z → A"}
      </button>

      {paginatedAlbums.map((album) => (
        <AlbumCard key={album.id} album={album} />
      ))}

      <button
        onClick={() => setPage((p) => Math.max(p - 1, 0))}
        disabled={page === 0}
        style={{
          opacity: page === 0 ? 0.5 : 1,
          cursor: page === 0 ? "not-allowed" : "pointer",
          marginRight: "10px"
        }}
      >
        Eelmine
      </button>

      <button
        onClick={() => setPage((p) => (p + 1 < totalPages ? p + 1 : p))}
        disabled={page + 1 >= totalPages}
        style={{
          opacity: page + 1 >= totalPages ? 0.5 : 1,
          cursor: page + 1 >= totalPages ? "not-allowed" : "pointer"
        }}
      >
        Järgmine
      </button>
    </div>
  );
}

export default AlbumListPage;
