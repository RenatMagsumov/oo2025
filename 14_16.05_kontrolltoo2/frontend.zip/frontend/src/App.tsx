import AlbumListPage from "./pages/AlbumListPage";

function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Albumi rakendus</h1>
      <AlbumListPage />
    </div>
  );
}

export default App;
