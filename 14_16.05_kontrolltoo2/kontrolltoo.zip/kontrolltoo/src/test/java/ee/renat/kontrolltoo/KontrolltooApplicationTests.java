package ee.renat.kontrolltoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KontrolltooApplicationTests {

	@Test
	void contextLoads() {
	}

}
