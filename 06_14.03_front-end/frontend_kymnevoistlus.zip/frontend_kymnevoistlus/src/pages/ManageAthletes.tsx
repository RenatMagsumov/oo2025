

function ManageAthletes() {
  return (
    <div>ManageAthletes</div>
  )
}

export default ManageAthletes